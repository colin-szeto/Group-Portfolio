# ChessOO

### Try to experiment with making an automated chess bot for the ASCII-Chess project using AI
